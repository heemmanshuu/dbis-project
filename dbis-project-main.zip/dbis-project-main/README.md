# dbis-project
Course project for CS 387 offered at IIT Bombay in the year 2021-2022

## Features link
https://docs.google.com/document/d/1WV4WJed6yh92U9kj4h5oJJb98gbiO5h6wb4gLSrHsqM/edit?usp=sharing

## Project Requirements and Analysis artifacts
https://docs.google.com/document/d/1Yj7X7U7xj4RjYZ9FAtD__KRI_bAuq91q3LYWGv-xzVU/edit?usp=sharing

## Project Test Plan
https://docs.google.com/document/d/1uDpSn3ZyALoizN5SA8txKQJ3gQmspppQFwrIp7A1FQE/edit?usp=sharing
